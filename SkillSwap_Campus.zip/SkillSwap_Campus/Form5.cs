﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SkillSwap_Campus
{
    public partial class EditAccForm : System.Windows.Forms.Form
    {
        string connectionString = "data source=CATCHER\\SQLEXPRESS; database=PC; integrated security=SSPI";
        int studentId;
        public EditAccForm()
        {
            InitializeComponent();
        }
        public EditAccForm(int id)
        {
            studentId = id;
            InitializeComponent();
            LoadProfileData();
        }

        private void LoadProfileData()
        {
            string query = "SELECT StudentName, Dept, Semester, Email, Phone FROM Students WHERE StudentId = @StudentId";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@StudentId", studentId);
                connection.Open();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        textBoxName.Text = reader["StudentName"].ToString();
                        comboBoxDept.Text = reader["Dept"].ToString();
                        comboBoxSem.Text = reader["Semester"].ToString();
                        textBoxEmail.Text = reader["Email"].ToString();
                        textBoxPhone.Text = reader["Phone"].ToString();
                    }
                }
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
            DashboardForm dashboardForm = new DashboardForm(studentId);
            dashboardForm.Show();
        }

        private void EditAccForm_Load(object sender, EventArgs e)
        {

        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
        
            var updates = new List<string>();
            var parameters = new List<SqlParameter>();


 
       



            if (!string.IsNullOrWhiteSpace(textBoxName.Text))
            {
                updates.Add("StudentName = @StudentName");
                parameters.Add(new SqlParameter("@StudentName", textBoxName.Text.Trim()));
            }

            if (!string.IsNullOrWhiteSpace(comboBoxDept.Text))
            {
                updates.Add("Dept = @Dept");
                parameters.Add(new SqlParameter("@Dept", comboBoxDept.Text.Trim()));
            }

            if (!string.IsNullOrWhiteSpace(comboBoxSem.Text))
            {
                updates.Add("Semester = @Semester");
                parameters.Add(new SqlParameter("@Semester", comboBoxSem.Text.Trim()));
            }

            if (!string.IsNullOrWhiteSpace(textBoxEmail.Text))
            {
                updates.Add("Email = @Email");
                parameters.Add(new SqlParameter("@Email", textBoxEmail.Text.Trim()));
            }

            if (!string.IsNullOrWhiteSpace(textBoxPhone.Text))
            {
                updates.Add("Phone = @Phone");
                parameters.Add(new SqlParameter("@Phone", textBoxPhone.Text.Trim()));
            }

            if (!string.IsNullOrWhiteSpace(textBoxPass.Text))
            {
                updates.Add("Password = @Password");
                parameters.Add(new SqlParameter("@Password", textBoxPass.Text.Trim()));
            }

            
            if (updates.Count == 0)
            {
                MessageBox.Show("Please enter at least one field you'd like to update.", "Nothing to Update", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query = "UPDATE Students SET " + string.Join(", ", updates) + " WHERE StudentId = @StudentId";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                foreach (var p in parameters)
                    command.Parameters.Add(p);

                command.Parameters.AddWithValue("@StudentId", studentId);

                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Profile updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Close();
                }
                else
                {
                    MessageBox.Show("Update failed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            DashboardForm dashboardForm = new DashboardForm(studentId);
            dashboardForm.Show();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
    }
