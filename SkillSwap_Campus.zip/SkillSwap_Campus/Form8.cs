﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SkillSwap_Campus
{
    public partial class ChatForm : System.Windows.Forms.Form
    {
        string connectionString = "data source=CATCHER\\SQLEXPRESS; database=PC; integrated security=SSPI";
        int interestId;
        int currentStudentId;
        int otherStudentId;
        string otherStudentName;
        bool isAuthorized = false;

        System.Windows.Forms.Timer timerRefresh = new System.Windows.Forms.Timer();
        public ChatForm()
        {
            InitializeComponent();
        }

        public ChatForm(int interestId, int currentStudentId)
        {
            this.interestId = interestId;
            this.currentStudentId = currentStudentId;
            InitializeComponent();
            this.Load += ChatForm_Load;
            this.FormClosing += ChatForm_FormClosing;
        }

        private void ChatForm_Load(object sender, EventArgs e)
        {
            if (!LoadParticipants())
            {
                MessageBox.Show("You're not authorized to view this conversation.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Close();
                return;
            }

            label1.Text = "Chatting with: " + otherStudentName;
            LoadMessages();

            timerRefresh.Interval = 3000;
            timerRefresh.Tick += (s, args) => LoadMessages();
            timerRefresh.Start();
        }

        private bool LoadParticipants()
        {
            string query = @"SELECT p.StudentId AS OwnerId, o.StudentName AS OwnerName,
                             i.StudentId AS RequesterId, r.StudentName AS RequesterName,
                             i.Status
                          FROM Interests i
                          INNER JOIN Posts p ON i.PostId = p.PostId
                          INNER JOIN Students o ON p.StudentId = o.StudentId
                          INNER JOIN Students r ON i.StudentId = r.StudentId
                          WHERE i.InterestId = @InterestId";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@InterestId", interestId);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (!reader.Read()) return false;

                    string status = reader["Status"].ToString();
                    if (status != "Accepted") return false;

                    int ownerId = Convert.ToInt32(reader["OwnerId"]);
                    int requesterId = Convert.ToInt32(reader["RequesterId"]);

                    if (currentStudentId == ownerId)
                    {
                        otherStudentId = requesterId;
                        otherStudentName = reader["RequesterName"].ToString();
                    }
                    else if (currentStudentId == requesterId)
                    {
                        otherStudentId = ownerId;
                        otherStudentName = reader["OwnerName"].ToString();
                    }
                    else
                    {
                        return false;
                    }

                    return true;
                }
            }
        }

        private void LoadMessages()
        {
            string query = @"SELECT s.StudentName, m.MessageText, m.SentAt, m.SenderId
                          FROM Messages m
                          INNER JOIN Students s ON m.SenderId = s.StudentId
                          WHERE m.InterestId = @InterestId
                          ORDER BY m.SentAt ASC";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@InterestId", interestId);
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);

                richTextBoxChat.Clear();
                foreach (DataRow row in dt.Rows)
                {
                    string sender = row["SenderId"].ToString() == currentStudentId.ToString() ? "You" : row["StudentName"].ToString();
                    DateTime sentAt = Convert.ToDateTime(row["SentAt"]);
                    richTextBoxChat.AppendText($"[{sentAt:HH:mm}] {sender}: {row["MessageText"]}\n");
                }

                richTextBoxChat.SelectionStart = richTextBoxChat.TextLength;
                richTextBoxChat.ScrollToCaret();
            }
        }

        private void buttonSend_Click(object sender, EventArgs e)
        {
            string text = textBoxMessage.Text.Trim();
            if (string.IsNullOrWhiteSpace(text)) return;

            string insertQuery = "INSERT INTO Messages (InterestId, SenderId, MessageText) VALUES (@InterestId, @SenderId, @MessageText)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(insertQuery, connection))
            {
                command.Parameters.AddWithValue("@InterestId", interestId);
                command.Parameters.AddWithValue("@SenderId", currentStudentId);
                command.Parameters.AddWithValue("@MessageText", text);
                connection.Open();
                command.ExecuteNonQuery();
            }

            textBoxMessage.Clear();
            LoadMessages();
        }

        private void textBoxMessage_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; 
                buttonSend_Click(sender, e);
            }
        }

        private void ChatForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            timerRefresh.Stop();
            timerRefresh.Dispose();
        }

    }
}
