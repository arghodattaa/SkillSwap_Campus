﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SkillSwap_Campus
{
    public partial class InterestsForm : System.Windows.Forms.Form
    {
        string connectionString = "data source=CATCHER\\SQLEXPRESS; database=PC; integrated security=SSPI";
        int postId;
        int currentStudentId;
        public InterestsForm()
        {
            InitializeComponent();
        }

        public InterestsForm(int postId, int currentStudentId)
        {
            this.postId = postId;
            this.currentStudentId = currentStudentId;
            InitializeComponent();
            LoadInterests();
        }

        private void LoadInterests()
        {
            string query = @"SELECT i.InterestId,
                             s.StudentId,
                             s.StudentName,
                             s.Email,
                             s.Phone,
                             i.Status,
                             i.CreatedAt
                          FROM Interests AS i
                          INNER JOIN Students AS s
                          ON i.StudentId = s.StudentId
                          WHERE i.PostId = @PostId
                          ORDER BY 
                             CASE i.Status WHEN 'Accepted' THEN 0 WHEN 'Pending' THEN 1 ELSE 2 END,
                             i.CreatedAt ASC";
            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@PostId", postId);
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);
                dataGridViewInterests.DataSource = dataTable;
            }

            if (dataGridViewInterests.Rows.Count == 0)
            {
                MessageBox.Show("No one has shown interest in this post yet.", "No Interests", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void InterestsForm_Load(object sender, EventArgs e)
        {

        }

        private void buttonAccept_Click(object sender, EventArgs e)
        {
            if (dataGridViewInterests.CurrentRow == null || dataGridViewInterests.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a student to accept.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow row = dataGridViewInterests.SelectedRows[0];
            int interestId = Convert.ToInt32(row.Cells["InterestId"].Value);
            string currentStatus = row.Cells["Status"].Value.ToString();
            string studentName = row.Cells["StudentName"].Value.ToString();

            if (currentStatus == "Accepted")
            {
                MessageBox.Show("This student has already been accepted.", "Already Accepted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DialogResult confirm = MessageBox.Show(
                $"Accept {studentName} for this post? Everyone else who showed interest will be automatically declined.",
                "Confirm Acceptance", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirm != DialogResult.Yes) return;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                try
                {
                    string acceptQuery = "UPDATE Interests SET Status = 'Accepted' WHERE InterestId = @InterestId";
                    using (SqlCommand acceptCommand = new SqlCommand(acceptQuery, connection, transaction))
                    {
                        acceptCommand.Parameters.AddWithValue("@InterestId", interestId);
                        acceptCommand.ExecuteNonQuery();
                    }
                    string rejectQuery = @"UPDATE Interests 
                                            SET Status = 'Rejected' 
                                            WHERE PostId = @PostId 
                                            AND InterestId <> @InterestId 
                                            AND Status = 'Pending'";
                    using (SqlCommand rejectCommand = new SqlCommand(rejectQuery, connection, transaction))
                    {
                        rejectCommand.Parameters.AddWithValue("@PostId", postId);
                        rejectCommand.Parameters.AddWithValue("@InterestId", interestId);
                        rejectCommand.ExecuteNonQuery();
                    }

                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    MessageBox.Show("Something went wrong while accepting this student. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            MessageBox.Show($"You accepted {studentName}! You can now reach out to them directly.", "Accepted", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadInterests();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Owner?.Show();
            this.Close();
        }

        private void buttonChat_Click(object sender, EventArgs e)
        {
            if (dataGridViewInterests.CurrentRow == null || dataGridViewInterests.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a student first.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow row = dataGridViewInterests.SelectedRows[0];

            if (row.Cells["Status"].Value.ToString() != "Accepted")
            {
                MessageBox.Show("You can only chat once you've accepted this student.", "Not Accepted Yet", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int interestId = Convert.ToInt32(row.Cells["InterestId"].Value);
            new ChatForm(interestId, currentStudentId).Show();
        }
    }
}
