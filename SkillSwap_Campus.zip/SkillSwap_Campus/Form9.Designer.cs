﻿namespace SkillSwap_Campus
{
    partial class AdminDashboardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminDashboardForm));
            this.tabControlAdmin = new System.Windows.Forms.TabControl();
            this.tabPageCourses = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonDeleteCourse = new System.Windows.Forms.Button();
            this.buttonAddCourse = new System.Windows.Forms.Button();
            this.textBoxNewCourseName = new System.Windows.Forms.TextBox();
            this.textBoxNewCourseId = new System.Windows.Forms.TextBox();
            this.dataGridViewCourses = new System.Windows.Forms.DataGridView();
            this.tabPagePosts = new System.Windows.Forms.TabPage();
            this.dataGridViewPosts = new System.Windows.Forms.DataGridView();
            this.buttonDeletePost = new System.Windows.Forms.Button();
            this.tabPageManageAdmins = new System.Windows.Forms.TabPage();
            this.buttonDemote = new System.Windows.Forms.Button();
            this.buttonPromote = new System.Windows.Forms.Button();
            this.dataGridViewStudents = new System.Windows.Forms.DataGridView();
            this.buttonLogOut = new System.Windows.Forms.Button();
            this.buttonViewAsStudent = new System.Windows.Forms.Button();
            this.tabControlAdmin.SuspendLayout();
            this.tabPageCourses.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCourses)).BeginInit();
            this.tabPagePosts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPosts)).BeginInit();
            this.tabPageManageAdmins.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStudents)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControlAdmin
            // 
            this.tabControlAdmin.Controls.Add(this.tabPageCourses);
            this.tabControlAdmin.Controls.Add(this.tabPagePosts);
            this.tabControlAdmin.Controls.Add(this.tabPageManageAdmins);
            this.tabControlAdmin.Location = new System.Drawing.Point(107, 71);
            this.tabControlAdmin.Name = "tabControlAdmin";
            this.tabControlAdmin.SelectedIndex = 0;
            this.tabControlAdmin.Size = new System.Drawing.Size(932, 481);
            this.tabControlAdmin.TabIndex = 0;
            // 
            // tabPageCourses
            // 
            this.tabPageCourses.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.tabPageCourses.Controls.Add(this.label2);
            this.tabPageCourses.Controls.Add(this.label1);
            this.tabPageCourses.Controls.Add(this.buttonDeleteCourse);
            this.tabPageCourses.Controls.Add(this.buttonAddCourse);
            this.tabPageCourses.Controls.Add(this.textBoxNewCourseName);
            this.tabPageCourses.Controls.Add(this.textBoxNewCourseId);
            this.tabPageCourses.Controls.Add(this.dataGridViewCourses);
            this.tabPageCourses.Location = new System.Drawing.Point(4, 25);
            this.tabPageCourses.Name = "tabPageCourses";
            this.tabPageCourses.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageCourses.Size = new System.Drawing.Size(924, 452);
            this.tabPageCourses.TabIndex = 0;
            this.tabPageCourses.Text = "Courses";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(365, 314);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Course Name :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(124, 314);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Course Id :";
            // 
            // buttonDeleteCourse
            // 
            this.buttonDeleteCourse.BackColor = System.Drawing.Color.Maroon;
            this.buttonDeleteCourse.Location = new System.Drawing.Point(629, 372);
            this.buttonDeleteCourse.Name = "buttonDeleteCourse";
            this.buttonDeleteCourse.Size = new System.Drawing.Size(115, 41);
            this.buttonDeleteCourse.TabIndex = 4;
            this.buttonDeleteCourse.Text = "Delete Course";
            this.buttonDeleteCourse.UseVisualStyleBackColor = false;
            this.buttonDeleteCourse.Click += new System.EventHandler(this.buttonDeleteCourse_Click);
            // 
            // buttonAddCourse
            // 
            this.buttonAddCourse.BackColor = System.Drawing.Color.Green;
            this.buttonAddCourse.Location = new System.Drawing.Point(629, 318);
            this.buttonAddCourse.Name = "buttonAddCourse";
            this.buttonAddCourse.Size = new System.Drawing.Size(115, 37);
            this.buttonAddCourse.TabIndex = 3;
            this.buttonAddCourse.Text = "Add Course";
            this.buttonAddCourse.UseVisualStyleBackColor = false;
            this.buttonAddCourse.Click += new System.EventHandler(this.buttonAddCourse_Click);
            // 
            // textBoxNewCourseName
            // 
            this.textBoxNewCourseName.Location = new System.Drawing.Point(368, 333);
            this.textBoxNewCourseName.Name = "textBoxNewCourseName";
            this.textBoxNewCourseName.Size = new System.Drawing.Size(216, 22);
            this.textBoxNewCourseName.TabIndex = 2;
            this.textBoxNewCourseName.TextChanged += new System.EventHandler(this.textBoxNewCourseName_TextChanged);
            // 
            // textBoxNewCourseId
            // 
            this.textBoxNewCourseId.Location = new System.Drawing.Point(127, 333);
            this.textBoxNewCourseId.Name = "textBoxNewCourseId";
            this.textBoxNewCourseId.Size = new System.Drawing.Size(216, 22);
            this.textBoxNewCourseId.TabIndex = 1;
            // 
            // dataGridViewCourses
            // 
            this.dataGridViewCourses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCourses.Location = new System.Drawing.Point(90, 45);
            this.dataGridViewCourses.Name = "dataGridViewCourses";
            this.dataGridViewCourses.RowHeadersWidth = 51;
            this.dataGridViewCourses.RowTemplate.Height = 24;
            this.dataGridViewCourses.Size = new System.Drawing.Size(732, 248);
            this.dataGridViewCourses.TabIndex = 0;
            // 
            // tabPagePosts
            // 
            this.tabPagePosts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tabPagePosts.Controls.Add(this.dataGridViewPosts);
            this.tabPagePosts.Controls.Add(this.buttonDeletePost);
            this.tabPagePosts.Location = new System.Drawing.Point(4, 25);
            this.tabPagePosts.Name = "tabPagePosts";
            this.tabPagePosts.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePosts.Size = new System.Drawing.Size(924, 452);
            this.tabPagePosts.TabIndex = 1;
            this.tabPagePosts.Text = "Posts";
            // 
            // dataGridViewPosts
            // 
            this.dataGridViewPosts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPosts.Location = new System.Drawing.Point(58, 42);
            this.dataGridViewPosts.Name = "dataGridViewPosts";
            this.dataGridViewPosts.RowHeadersWidth = 51;
            this.dataGridViewPosts.RowTemplate.Height = 24;
            this.dataGridViewPosts.Size = new System.Drawing.Size(806, 328);
            this.dataGridViewPosts.TabIndex = 1;
            // 
            // buttonDeletePost
            // 
            this.buttonDeletePost.BackColor = System.Drawing.Color.Maroon;
            this.buttonDeletePost.Location = new System.Drawing.Point(392, 390);
            this.buttonDeletePost.Name = "buttonDeletePost";
            this.buttonDeletePost.Size = new System.Drawing.Size(129, 43);
            this.buttonDeletePost.TabIndex = 0;
            this.buttonDeletePost.Text = "Delete Post";
            this.buttonDeletePost.UseVisualStyleBackColor = false;
            this.buttonDeletePost.Click += new System.EventHandler(this.buttonDeletePost_Click);
            // 
            // tabPageManageAdmins
            // 
            this.tabPageManageAdmins.BackColor = System.Drawing.Color.CadetBlue;
            this.tabPageManageAdmins.Controls.Add(this.buttonDemote);
            this.tabPageManageAdmins.Controls.Add(this.buttonPromote);
            this.tabPageManageAdmins.Controls.Add(this.dataGridViewStudents);
            this.tabPageManageAdmins.Location = new System.Drawing.Point(4, 25);
            this.tabPageManageAdmins.Name = "tabPageManageAdmins";
            this.tabPageManageAdmins.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageManageAdmins.Size = new System.Drawing.Size(924, 452);
            this.tabPageManageAdmins.TabIndex = 2;
            this.tabPageManageAdmins.Text = "Manage Admins";
            // 
            // buttonDemote
            // 
            this.buttonDemote.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonDemote.Location = new System.Drawing.Point(708, 229);
            this.buttonDemote.Name = "buttonDemote";
            this.buttonDemote.Size = new System.Drawing.Size(153, 54);
            this.buttonDemote.TabIndex = 2;
            this.buttonDemote.Text = "Demote To Student";
            this.buttonDemote.UseVisualStyleBackColor = false;
            this.buttonDemote.Click += new System.EventHandler(this.buttonDemote_Click);
            // 
            // buttonPromote
            // 
            this.buttonPromote.BackColor = System.Drawing.Color.Green;
            this.buttonPromote.Location = new System.Drawing.Point(708, 134);
            this.buttonPromote.Name = "buttonPromote";
            this.buttonPromote.Size = new System.Drawing.Size(153, 49);
            this.buttonPromote.TabIndex = 1;
            this.buttonPromote.Text = "Promote to Admin";
            this.buttonPromote.UseVisualStyleBackColor = false;
            this.buttonPromote.Click += new System.EventHandler(this.buttonPromote_Click);
            // 
            // dataGridViewStudents
            // 
            this.dataGridViewStudents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewStudents.Location = new System.Drawing.Point(65, 45);
            this.dataGridViewStudents.Name = "dataGridViewStudents";
            this.dataGridViewStudents.RowHeadersWidth = 51;
            this.dataGridViewStudents.RowTemplate.Height = 24;
            this.dataGridViewStudents.Size = new System.Drawing.Size(568, 341);
            this.dataGridViewStudents.TabIndex = 0;
            // 
            // buttonLogOut
            // 
            this.buttonLogOut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonLogOut.Location = new System.Drawing.Point(527, 587);
            this.buttonLogOut.Name = "buttonLogOut";
            this.buttonLogOut.Size = new System.Drawing.Size(75, 31);
            this.buttonLogOut.TabIndex = 1;
            this.buttonLogOut.Text = "Log out";
            this.buttonLogOut.UseVisualStyleBackColor = false;
            this.buttonLogOut.Click += new System.EventHandler(this.buttonLogOut_Click);
            // 
            // buttonViewAsStudent
            // 
            this.buttonViewAsStudent.BackColor = System.Drawing.Color.Teal;
            this.buttonViewAsStudent.Location = new System.Drawing.Point(887, 34);
            this.buttonViewAsStudent.Name = "buttonViewAsStudent";
            this.buttonViewAsStudent.Size = new System.Drawing.Size(148, 47);
            this.buttonViewAsStudent.TabIndex = 2;
            this.buttonViewAsStudent.Text = "View as Student";
            this.buttonViewAsStudent.UseVisualStyleBackColor = false;
            this.buttonViewAsStudent.Click += new System.EventHandler(this.buttonViewAsStudent_Click);
            // 
            // AdminDashboardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(26)))), ((int)(((byte)(32)))));
            this.ClientSize = new System.Drawing.Size(1152, 649);
            this.Controls.Add(this.buttonViewAsStudent);
            this.Controls.Add(this.buttonLogOut);
            this.Controls.Add(this.tabControlAdmin);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AdminDashboardForm";
            this.Text = "Admin Dashboard Form";
            this.Load += new System.EventHandler(this.AdminDashboardForm_Load);
            this.tabControlAdmin.ResumeLayout(false);
            this.tabPageCourses.ResumeLayout(false);
            this.tabPageCourses.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCourses)).EndInit();
            this.tabPagePosts.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPosts)).EndInit();
            this.tabPageManageAdmins.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStudents)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlAdmin;
        private System.Windows.Forms.TabPage tabPageCourses;
        private System.Windows.Forms.TabPage tabPagePosts;
        private System.Windows.Forms.Button buttonAddCourse;
        private System.Windows.Forms.TextBox textBoxNewCourseName;
        private System.Windows.Forms.TextBox textBoxNewCourseId;
        private System.Windows.Forms.DataGridView dataGridViewCourses;
        private System.Windows.Forms.Button buttonDeleteCourse;
        private System.Windows.Forms.DataGridView dataGridViewPosts;
        private System.Windows.Forms.Button buttonDeletePost;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonLogOut;
        private System.Windows.Forms.Button buttonViewAsStudent;
        private System.Windows.Forms.TabPage tabPageManageAdmins;
        private System.Windows.Forms.Button buttonDemote;
        private System.Windows.Forms.Button buttonPromote;
        private System.Windows.Forms.DataGridView dataGridViewStudents;
    }
}