﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace SkillSwap_Campus
{
    public partial class PostForm : System.Windows.Forms.Form
    {
        public PostForm()
        {
            InitializeComponent();
        }
        int studentId;
        public PostForm(int studentId)
        {
            InitializeComponent();
            this.studentId = studentId;
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Owner.Show();
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "data source=CATCHER\\SQLEXPRESS; database=PC; integrated security=SSPI";

            string courseName = textBoxCourseName.Text.Trim();
            string courseId = textBoxCourseId.Text.Trim();
            string rate = textBoxRate.Text.Trim();
            string title = "";
            if (radioButtonLearn.Checked) title = radioButtonLearn.Text;
            else if (radioButtonTeach.Checked) title = radioButtonTeach.Text;
            string description = richTextBoxDescription.Text.Trim();
            string id = studentId.ToString();

            if (string.IsNullOrWhiteSpace(courseId) || string.IsNullOrWhiteSpace(courseName) || string.IsNullOrWhiteSpace(rate) ||
                 string.IsNullOrWhiteSpace(title) || string.IsNullOrWhiteSpace(description) || string.IsNullOrWhiteSpace(id))
            {
                MessageBox.Show("All fields must be filled out.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT COUNT(1) FROM Courses WHERE CourseId = @courseId";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@courseId", courseId);
                    int exists = (int)cmd.ExecuteScalar();

                    if (exists == 0)
                    {
                        string insertCourseQuery = "INSERT INTO Courses (CourseId, CourseName) VALUES (@courseId, @courseName)";
                        using (SqlCommand insertCourseCmd = new SqlCommand(insertCourseQuery, connection))
                        {
                            insertCourseCmd.Parameters.AddWithValue("@courseId", courseId);
                            insertCourseCmd.Parameters.AddWithValue("@courseName", courseName);
                            insertCourseCmd.ExecuteNonQuery();
                        }
                    }
                }

               
                string insertPostQuery = "INSERT INTO Posts (Title, Rate, Description, StudentId, CourseId) " +
                                          "VALUES (@title, @rate, @description, @StudentId, @courseId)";
                using (SqlCommand command = new SqlCommand(insertPostQuery, connection))
                {
                    command.Parameters.AddWithValue("@courseId", courseId);
                    command.Parameters.AddWithValue("@rate", rate);
                    command.Parameters.AddWithValue("@title", title);
                    command.Parameters.AddWithValue("@description", description);
                    command.Parameters.AddWithValue("@StudentId", id);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Post created successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                        DashboardForm f1 = new DashboardForm(studentId);
                        f1.Show();
                    }
                    else
                    {
                        MessageBox.Show("Failed to Post. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void PostForm_Load(object sender, EventArgs e)
        {

        }
    }
    }
