﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SkillSwap_Campus
{
    public partial class DeletePostForm : System.Windows.Forms.Form
    {
        string connectionString = "data source=CATCHER\\SQLEXPRESS; database=PC; integrated security=SSPI";
        string postId; 

        public DeletePostForm()
        {
            InitializeComponent();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            
            string postIdText = textBoxPostId.Text.Trim();

            if (!int.TryParse(postIdText, out int postId))
            {
                MessageBox.Show("Post ID must be a valid number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();
                int rowsAffected;

                try
                {
                    string deleteMessagesQuery = @"DELETE FROM Messages 
                                            WHERE InterestId IN (SELECT InterestId FROM Interests WHERE PostId = @PostId)";
                    using (SqlCommand cmd = new SqlCommand(deleteMessagesQuery, connection, transaction))
                    {
                        cmd.Parameters.Add("@PostId", SqlDbType.Int).Value = postId;
                        cmd.ExecuteNonQuery();
                    }

                    string deleteInterestsQuery = "DELETE FROM Interests WHERE PostId = @PostId";
                    using (SqlCommand cmd = new SqlCommand(deleteInterestsQuery, connection, transaction))
                    {
                        cmd.Parameters.Add("@PostId", SqlDbType.Int).Value = postId;
                        cmd.ExecuteNonQuery();
                    }

                    string deletePostQuery = "DELETE FROM Posts WHERE PostId = @PostId";
                    using (SqlCommand cmd = new SqlCommand(deletePostQuery, connection, transaction))
                    {
                        cmd.Parameters.Add("@PostId", SqlDbType.Int).Value = postId;
                        rowsAffected = cmd.ExecuteNonQuery();
                    }

                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    MessageBox.Show("Something went wrong while deleting this post. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Post deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Close();
                }
                else
                {
                    MessageBox.Show("No post was found to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
            
        

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void DeletePostForm_Load(object sender, EventArgs e)
        {

        }
    }
}
