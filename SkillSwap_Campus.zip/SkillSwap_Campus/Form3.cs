﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SkillSwap_Campus
{
    public partial class DashboardForm : System.Windows.Forms.Form
    {
        string connectionString = "data source=CATCHER\\SQLEXPRESS; database=PC; integrated security=SSPI";
        public DashboardForm()
        {
            InitializeComponent();
            StyleDataGridViewDark();
        }

        int studentId;
        public DashboardForm(int i)
        {
            studentId = i;
            InitializeComponent();
            StyleDataGridViewDark();
            string query = @"SELECT p.PostId,
                             p.Title,
                             p.StudentId,
                             c.CourseName,
                             p.Description,
                             p.Rate,
                             s.phone,
                             s.Email
                          FROM Posts AS p
                          INNER JOIN Students AS s
                          ON p.StudentId = s.StudentId
                          INNER JOIN Courses AS c
                          ON p.CourseId = c.CourseId
                          WHERE NOT EXISTS (
                      SELECT 1 FROM Interests i
                      WHERE i.PostId = p.PostId AND i.Status = 'Accepted'
                  )";
            FillDataGridView(query);
        }

        private void FillDataGridView(string query)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    con.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);
                    dataGridView1.DataSource = dataTable;
                }
            }

        }
        private void StyleDataGridViewDark()
        {
            dataGridView1.BackgroundColor = ColorTranslator.FromHtml("#12141C");
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.GridColor = ColorTranslator.FromHtml("#2A2E3A");
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.AllowUserToAddRows = false;

            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.MultiSelect = false;

            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#1B1F2A");
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);

            dataGridView1.DefaultCellStyle.BackColor = ColorTranslator.FromHtml("#1B1F2A");
            dataGridView1.DefaultCellStyle.ForeColor = Color.White;
            dataGridView1.DefaultCellStyle.SelectionBackColor = ColorTranslator.FromHtml("#1D9E75");
            dataGridView1.DefaultCellStyle.SelectionForeColor = Color.White;
            dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#20242F");
        }
        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridView1.Columns[e.ColumnIndex].Name != "Status" || e.Value == null) return;

            switch (e.Value.ToString())
            {
                case "Accepted":
                    e.CellStyle.BackColor = Color.LightGreen;
                    break;
                case "Rejected":
                    e.CellStyle.BackColor = Color.MistyRose;
                    break;
                case "Pending":
                    e.CellStyle.BackColor = Color.LightYellow;
                    break;
            }
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            buttonOpenChat.Visible = false;
            string searchValue = textBoxSearch.Text.Trim();

            if (string.IsNullOrWhiteSpace(searchValue))
            {
                MessageBox.Show("Please enter a search term.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query = @"SELECT p.PostId,
                             p.Title,
                             p.StudentId,
                             c.CourseName,
                             p.Description,
                             p.Rate
                          FROM Posts AS p
                          INNER JOIN Students AS s
                          ON p.StudentId = s.StudentId
                          INNER JOIN Courses AS c
                          ON p.CourseId = c.CourseId
                 WHERE CAST(p.StudentId AS VARCHAR(50)) LIKE @searchTerm
                 OR CAST(p.CourseId AS VARCHAR(50)) LIKE @searchTerm
                 OR CAST(c.CourseName AS VARCHAR(50)) LIKE @searchTerm";



            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@searchTerm", "%" + searchValue + "%");

                   
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);
                    dataGridView1.DataSource = dataTable;

                    if (dataTable.Rows.Count == 0)
                    {
                        MessageBox.Show("No matching rows found.", "Search Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void buttonCreatePost_Click(object sender, EventArgs e)
        {

            PostForm form2 = new PostForm(studentId);
            form2.Owner = this;
            form2.Show();
            this.Hide();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
         "Are you sure you want to exit the application?",
         "Confirm Exit",
         MessageBoxButtons.YesNo,
         MessageBoxIcon.Question
  );

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void buttonEditAcc_Click(object sender, EventArgs e)
        {
            this.Hide();
            EditAccForm f3 = new EditAccForm(studentId);
            f3.Show();
        }

        private void buttonDeleteAcc_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
            "Are you sure you want to delete this profile?",
            "Confirm Deletion",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning
);

            if (result == DialogResult.Yes)
            {
                string query = "DELETE FROM Students WHERE StudentId = @StudentId; " +
                               "DELETE FROM Posts WHERE StudentId = @StudentId";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@StudentId", studentId);

                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Profile deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            Close();
                        }
                        else
                        {
                            MessageBox.Show("No profile was found to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }
        private void FillDataGridView(string query, string studentId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@studentId", studentId);

                    SqlDataReader reader = command.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    dataGridView1.DataSource = dt;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            buttonOpenChat.Visible = false;
            string sId = studentId.ToString();
            string query = @"SELECT p.PostId, p.Title, p.Description, p.CourseId, c.CourseName FROM Posts AS p INNER JOIN Courses AS c ON p.CourseId = c.CourseId INNER JOIN Students AS s ON p.StudentId = s.StudentId WHERE p.StudentId = @studentId ORDER BY p.PostId ";

           
                FillDataGridView(query, sId);
            }

        private void buttonAllPosts_Click(object sender, EventArgs e)
        {
            buttonOpenChat.Visible = false;
            string query = @"SELECT p.PostId,
                             p.Title,
                             p.StudentId,
                             c.CourseName,
                             p.Description,
                             p.Rate,
                             s.phone,
                             s.Email
                          FROM Posts AS p
                          INNER JOIN Students AS s
                          ON p.StudentId = s.StudentId
                          INNER JOIN Courses AS c
                          ON p.CourseId = c.CourseId
                          WHERE NOT EXISTS (
                      SELECT 1 FROM Interests i
                      WHERE i.PostId = p.PostId AND i.Status = 'Accepted'
                  )";
            FillDataGridView(query);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DeletePostForm df = new DeletePostForm();
            df.Show();
        }

        private void DashboardForm_Load(object sender, EventArgs e)
        {

        }

        private void buttonLogOut_Click(object sender, EventArgs e)
        {
            var confirm = MessageBox.Show(
                "Are you sure you want to logout?",
                "Confirm Logout",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirm == DialogResult.Yes)
            {

                LoginForm loginForm = new LoginForm();
                loginForm.Show();

                this.Close();
            }
        }

        private void buttonTutor_Click(object sender, EventArgs e)
        {
            buttonOpenChat.Visible = false;
            string query = @"SELECT p.StudentId,
                     c.CourseName,
                     p.Description,
                     p.Rate,
                     s.phone,
                     s.Email
                  FROM Posts AS p
                  INNER JOIN Students AS s
                  ON p.StudentId = s.StudentId
                  INNER JOIN Courses AS c
                  ON p.CourseId = c.CourseId
                  WHERE p.Title = @title";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@title", "Want to Teach");

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);
                    dataGridView1.DataSource = dataTable;

                    if (dataTable.Rows.Count == 0)
                    {
                        MessageBox.Show("No Tutor's post was found.", "No Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void buttonLearner_Click(object sender, EventArgs e)
        {   buttonOpenChat.Visible = false;
            string query = @"SELECT p.StudentId,
                     c.CourseName,
                     p.Description,
                     p.Rate,
                     s.phone,
                     s.Email
                  FROM Posts AS p
                  INNER JOIN Students AS s
                  ON p.StudentId = s.StudentId
                  INNER JOIN Courses AS c
                  ON p.CourseId = c.CourseId
                  WHERE p.Title = @title";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@title", "Want to Learn");

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);
                    dataGridView1.DataSource = dataTable;

                    if (dataTable.Rows.Count == 0)
                    {
                        MessageBox.Show("No learner's post was found.", "No Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void buttonShowInterest_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null || dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a post first.", "No Post Selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow row = dataGridView1.SelectedRows[0];

            if (row.Cells["PostId"].Value == null)
            {
                MessageBox.Show("Please select a post from the main listing.", "Unavailable", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int postId = Convert.ToInt32(row.Cells["PostId"].Value);
            string postOwnerId = row.Cells["StudentId"].Value.ToString();

            if (postOwnerId == studentId.ToString())
            {
                MessageBox.Show("You can't show interest in your own post.", "Not Allowed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string checkQuery = "SELECT COUNT(1) FROM Interests WHERE PostId = @PostId AND StudentId = @StudentId";
                using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                {
                    checkCommand.Parameters.AddWithValue("@PostId", postId);
                    checkCommand.Parameters.AddWithValue("@StudentId", studentId);

                    if ((int)checkCommand.ExecuteScalar() > 0)
                    {
                        MessageBox.Show("You've already shown interest in this post.", "Already Interested", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }
                string insertQuery = "INSERT INTO Interests (PostId, StudentId, Status) VALUES (@PostId, @StudentId, 'Pending')";
                using (SqlCommand insertCommand = new SqlCommand(insertQuery, connection))
                {
                    insertCommand.Parameters.AddWithValue("@PostId", postId);
                    insertCommand.Parameters.AddWithValue("@StudentId", studentId);

                    if (insertCommand.ExecuteNonQuery() > 0)
                        MessageBox.Show("Your interest has been sent to the post creator!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show("Failed to register your interest. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }




        }

        private void buttonViewInterest_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null || dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select one of your posts first.", "No Post Selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow row = dataGridView1.SelectedRows[0];

            if (row.Cells["PostId"].Value == null)
            {
                MessageBox.Show("Please select a post from the 'My Posts' list.", "Unavailable", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int postId = Convert.ToInt32(row.Cells["PostId"].Value);

            
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string ownerQuery = "SELECT StudentId FROM Posts WHERE PostId = @PostId";
                using (SqlCommand ownerCommand = new SqlCommand(ownerQuery, connection))
                {
                    ownerCommand.Parameters.AddWithValue("@PostId", postId);
                    object result = ownerCommand.ExecuteScalar();

                    if (result == null || result.ToString() != studentId.ToString())
                    {
                        MessageBox.Show("You can only view interested students for your own posts.", "Not Allowed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }

            }

            InterestsForm interestsForm = new InterestsForm(postId, studentId);
            interestsForm.Owner = this;
            interestsForm.Show();
            this.Hide();

        }

        private void buttonMyInterests_Click(object sender, EventArgs e)
        {
            buttonOpenChat.Visible = false;
            string sId = studentId.ToString();

            string query = @"SELECT i.InterestId,
                     i.PostId,
                     p.Title,
                     c.CourseName,
                     p.Description,
                     p.Rate,
                     i.Status,
                     CASE WHEN i.Status = 'Accepted' THEN s.StudentName ELSE 'Hidden until accepted' END AS PostedBy,
                     CASE WHEN i.Status = 'Accepted' THEN s.Phone ELSE '-' END AS ContactPhone,
                     CASE WHEN i.Status = 'Accepted' THEN s.Email ELSE '-' END AS ContactEmail,
                     i.CreatedAt
                  FROM Interests AS i
                  INNER JOIN Posts AS p ON i.PostId = p.PostId
                  INNER JOIN Courses AS c ON p.CourseId = c.CourseId
                  INNER JOIN Students AS s ON p.StudentId = s.StudentId
                  WHERE i.StudentId = @studentId
                  ORDER BY 
                     CASE i.Status WHEN 'Accepted' THEN 0 WHEN 'Pending' THEN 1 ELSE 2 END,
                     i.CreatedAt DESC";

            FillDataGridView(query, sId);
            if (dataGridView1.Rows.Count == 0)
            {
                MessageBox.Show("You haven't shown interest in any posts yet.", "No Interests", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void buttonMessage_Click(object sender, EventArgs e)
        {
            string query = @"SELECT i.InterestId,
                     p.Title AS PostTitle,
                     CASE WHEN p.StudentId = @studentId THEN r.StudentName ELSE o.StudentName END AS ChattingWith,
                     CASE WHEN p.StudentId = @studentId THEN 'You posted this' ELSE 'You requested this' END AS YourRole,
                     i.CreatedAt AS MatchedOn
                  FROM Interests i
                  INNER JOIN Posts p ON i.PostId = p.PostId
                  INNER JOIN Students o ON p.StudentId = o.StudentId
                  INNER JOIN Students r ON i.StudentId = r.StudentId
                  WHERE i.Status = 'Accepted'
                  AND (p.StudentId = @studentId OR i.StudentId = @studentId)
                  ORDER BY i.CreatedAt DESC";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@studentId", studentId);
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridView1.DataSource = dt;
            }
            buttonOpenChat.Visible = dataGridView1.Rows.Count > 0;

            if (dataGridView1.Rows.Count == 0)
            {
                MessageBox.Show("You don't have any active conversations yet.", "No Messages", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void buttonOpenChat_Click(object sender, EventArgs e)
        {
            if (!dataGridView1.Columns.Contains("InterestId"))
            {
                MessageBox.Show("Please open 'Messages' first, then select a conversation.", "Wrong View", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dataGridView1.CurrentRow == null || dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a conversation.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int interestId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["InterestId"].Value);
            new ChatForm(interestId, studentId).Show();
        }
    }
}
    
    

