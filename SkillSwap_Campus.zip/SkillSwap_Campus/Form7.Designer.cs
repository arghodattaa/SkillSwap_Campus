﻿namespace SkillSwap_Campus
{
    partial class InterestsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InterestsForm));
            this.dataGridViewInterests = new System.Windows.Forms.DataGridView();
            this.buttonAccept = new System.Windows.Forms.Button();
            this.buttonBack = new System.Windows.Forms.Button();
            this.buttonChat = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewInterests)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewInterests
            // 
            this.dataGridViewInterests.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewInterests.Location = new System.Drawing.Point(75, 59);
            this.dataGridViewInterests.Name = "dataGridViewInterests";
            this.dataGridViewInterests.RowHeadersWidth = 51;
            this.dataGridViewInterests.RowTemplate.Height = 24;
            this.dataGridViewInterests.Size = new System.Drawing.Size(650, 272);
            this.dataGridViewInterests.TabIndex = 0;
            // 
            // buttonAccept
            // 
            this.buttonAccept.BackColor = System.Drawing.Color.Green;
            this.buttonAccept.Location = new System.Drawing.Point(222, 352);
            this.buttonAccept.Name = "buttonAccept";
            this.buttonAccept.Size = new System.Drawing.Size(123, 48);
            this.buttonAccept.TabIndex = 1;
            this.buttonAccept.Text = "Accept";
            this.buttonAccept.UseVisualStyleBackColor = false;
            this.buttonAccept.Click += new System.EventHandler(this.buttonAccept_Click);
            // 
            // buttonBack
            // 
            this.buttonBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonBack.Location = new System.Drawing.Point(342, 406);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(106, 33);
            this.buttonBack.TabIndex = 2;
            this.buttonBack.Text = "Back";
            this.buttonBack.UseVisualStyleBackColor = false;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // buttonChat
            // 
            this.buttonChat.BackColor = System.Drawing.Color.Teal;
            this.buttonChat.Location = new System.Drawing.Point(445, 352);
            this.buttonChat.Name = "buttonChat";
            this.buttonChat.Size = new System.Drawing.Size(123, 48);
            this.buttonChat.TabIndex = 3;
            this.buttonChat.Text = "Chat";
            this.buttonChat.UseVisualStyleBackColor = false;
            this.buttonChat.Click += new System.EventHandler(this.buttonChat_Click);
            // 
            // InterestsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(26)))), ((int)(((byte)(32)))));
            this.ClientSize = new System.Drawing.Size(800, 482);
            this.Controls.Add(this.buttonChat);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.buttonAccept);
            this.Controls.Add(this.dataGridViewInterests);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "InterestsForm";
            this.Text = "Interests Form";
            this.Load += new System.EventHandler(this.InterestsForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewInterests)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewInterests;
        private System.Windows.Forms.Button buttonAccept;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.Button buttonChat;
    }
}