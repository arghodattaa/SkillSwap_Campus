﻿namespace SkillSwap_Campus
{
    partial class DashboardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashboardForm));
            this.buttonSearch = new System.Windows.Forms.Button();
            this.buttonCreatePost = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonEditAcc = new System.Windows.Forms.Button();
            this.buttonDeleteAcc = new System.Windows.Forms.Button();
            this.buttonMyPost = new System.Windows.Forms.Button();
            this.buttonDeletePost = new System.Windows.Forms.Button();
            this.buttonAllPosts = new System.Windows.Forms.Button();
            this.buttonLogOut = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonTutor = new System.Windows.Forms.Button();
            this.buttonLearner = new System.Windows.Forms.Button();
            this.buttonShowInterest = new System.Windows.Forms.Button();
            this.buttonViewInterest = new System.Windows.Forms.Button();
            this.buttonMyInterests = new System.Windows.Forms.Button();
            this.buttonMessage = new System.Windows.Forms.Button();
            this.buttonOpenChat = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonSearch
            // 
            this.buttonSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonSearch.Location = new System.Drawing.Point(577, 81);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size(119, 33);
            this.buttonSearch.TabIndex = 0;
            this.buttonSearch.Text = "Search";
            this.buttonSearch.UseVisualStyleBackColor = false;
            this.buttonSearch.Click += new System.EventHandler(this.buttonSearch_Click);
            // 
            // buttonCreatePost
            // 
            this.buttonCreatePost.BackColor = System.Drawing.Color.OliveDrab;
            this.buttonCreatePost.Location = new System.Drawing.Point(1069, 71);
            this.buttonCreatePost.Name = "buttonCreatePost";
            this.buttonCreatePost.Size = new System.Drawing.Size(163, 53);
            this.buttonCreatePost.TabIndex = 1;
            this.buttonCreatePost.Text = "Create New Post";
            this.buttonCreatePost.UseVisualStyleBackColor = false;
            this.buttonCreatePost.Click += new System.EventHandler(this.buttonCreatePost_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.Color.Chocolate;
            this.dataGridView1.Location = new System.Drawing.Point(199, 129);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1033, 479);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(47)))), ((int)(((byte)(56)))));
            this.textBoxSearch.Location = new System.Drawing.Point(199, 87);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(372, 22);
            this.textBoxSearch.TabIndex = 3;
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonExit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonExit.Location = new System.Drawing.Point(663, 614);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(82, 32);
            this.buttonExit.TabIndex = 4;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonEditAcc
            // 
            this.buttonEditAcc.BackColor = System.Drawing.Color.RoyalBlue;
            this.buttonEditAcc.Location = new System.Drawing.Point(1069, 12);
            this.buttonEditAcc.Name = "buttonEditAcc";
            this.buttonEditAcc.Size = new System.Drawing.Size(133, 41);
            this.buttonEditAcc.TabIndex = 5;
            this.buttonEditAcc.Text = "Edit Account";
            this.buttonEditAcc.UseVisualStyleBackColor = false;
            this.buttonEditAcc.Click += new System.EventHandler(this.buttonEditAcc_Click);
            // 
            // buttonDeleteAcc
            // 
            this.buttonDeleteAcc.BackColor = System.Drawing.Color.OrangeRed;
            this.buttonDeleteAcc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.buttonDeleteAcc.Location = new System.Drawing.Point(34, 551);
            this.buttonDeleteAcc.Name = "buttonDeleteAcc";
            this.buttonDeleteAcc.Size = new System.Drawing.Size(132, 38);
            this.buttonDeleteAcc.TabIndex = 6;
            this.buttonDeleteAcc.Text = "Delete Account";
            this.buttonDeleteAcc.UseVisualStyleBackColor = false;
            this.buttonDeleteAcc.Click += new System.EventHandler(this.buttonDeleteAcc_Click);
            // 
            // buttonMyPost
            // 
            this.buttonMyPost.BackColor = System.Drawing.Color.Olive;
            this.buttonMyPost.Location = new System.Drawing.Point(51, 136);
            this.buttonMyPost.Name = "buttonMyPost";
            this.buttonMyPost.Size = new System.Drawing.Size(115, 49);
            this.buttonMyPost.TabIndex = 7;
            this.buttonMyPost.Text = "My Posts";
            this.buttonMyPost.UseVisualStyleBackColor = false;
            this.buttonMyPost.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonDeletePost
            // 
            this.buttonDeletePost.BackColor = System.Drawing.Color.Indigo;
            this.buttonDeletePost.Location = new System.Drawing.Point(43, 480);
            this.buttonDeletePost.Name = "buttonDeletePost";
            this.buttonDeletePost.Size = new System.Drawing.Size(116, 47);
            this.buttonDeletePost.TabIndex = 8;
            this.buttonDeletePost.Text = "Delete My Post";
            this.buttonDeletePost.UseVisualStyleBackColor = false;
            this.buttonDeletePost.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonAllPosts
            // 
            this.buttonAllPosts.BackColor = System.Drawing.Color.DarkGreen;
            this.buttonAllPosts.Location = new System.Drawing.Point(716, 71);
            this.buttonAllPosts.Name = "buttonAllPosts";
            this.buttonAllPosts.Size = new System.Drawing.Size(108, 57);
            this.buttonAllPosts.TabIndex = 9;
            this.buttonAllPosts.Text = "All Posts";
            this.buttonAllPosts.UseVisualStyleBackColor = false;
            this.buttonAllPosts.Click += new System.EventHandler(this.buttonAllPosts_Click);
            // 
            // buttonLogOut
            // 
            this.buttonLogOut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonLogOut.Location = new System.Drawing.Point(1221, 12);
            this.buttonLogOut.Name = "buttonLogOut";
            this.buttonLogOut.Size = new System.Drawing.Size(92, 41);
            this.buttonLogOut.TabIndex = 11;
            this.buttonLogOut.Text = "Log Out";
            this.buttonLogOut.UseVisualStyleBackColor = false;
            this.buttonLogOut.Click += new System.EventHandler(this.buttonLogOut_Click);
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::SkillSwap_Campus.Properties.Resources.file_00000000f708820b89cd978f03732d01;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Location = new System.Drawing.Point(21, 22);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(159, 101);
            this.panel1.TabIndex = 10;
            // 
            // buttonTutor
            // 
            this.buttonTutor.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonTutor.Location = new System.Drawing.Point(830, 72);
            this.buttonTutor.Name = "buttonTutor";
            this.buttonTutor.Size = new System.Drawing.Size(110, 52);
            this.buttonTutor.TabIndex = 12;
            this.buttonTutor.Text = "Tutor\'s Posts";
            this.buttonTutor.UseVisualStyleBackColor = false;
            this.buttonTutor.Click += new System.EventHandler(this.buttonTutor_Click);
            // 
            // buttonLearner
            // 
            this.buttonLearner.BackColor = System.Drawing.Color.RosyBrown;
            this.buttonLearner.Location = new System.Drawing.Point(946, 71);
            this.buttonLearner.Name = "buttonLearner";
            this.buttonLearner.Size = new System.Drawing.Size(117, 55);
            this.buttonLearner.TabIndex = 13;
            this.buttonLearner.Text = "Learner\'s Posts";
            this.buttonLearner.UseVisualStyleBackColor = false;
            this.buttonLearner.Click += new System.EventHandler(this.buttonLearner_Click);
            // 
            // buttonShowInterest
            // 
            this.buttonShowInterest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonShowInterest.Location = new System.Drawing.Point(1238, 136);
            this.buttonShowInterest.Name = "buttonShowInterest";
            this.buttonShowInterest.Size = new System.Drawing.Size(75, 63);
            this.buttonShowInterest.TabIndex = 15;
            this.buttonShowInterest.Text = "Show Interest";
            this.buttonShowInterest.UseVisualStyleBackColor = false;
            this.buttonShowInterest.Click += new System.EventHandler(this.buttonShowInterest_Click);
            // 
            // buttonViewInterest
            // 
            this.buttonViewInterest.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.buttonViewInterest.Location = new System.Drawing.Point(52, 207);
            this.buttonViewInterest.Name = "buttonViewInterest";
            this.buttonViewInterest.Size = new System.Drawing.Size(107, 62);
            this.buttonViewInterest.TabIndex = 16;
            this.buttonViewInterest.Text = "View Interests on My Posts";
            this.buttonViewInterest.UseVisualStyleBackColor = false;
            this.buttonViewInterest.Click += new System.EventHandler(this.buttonViewInterest_Click);
            // 
            // buttonMyInterests
            // 
            this.buttonMyInterests.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.buttonMyInterests.Location = new System.Drawing.Point(51, 289);
            this.buttonMyInterests.Name = "buttonMyInterests";
            this.buttonMyInterests.Size = new System.Drawing.Size(108, 49);
            this.buttonMyInterests.TabIndex = 17;
            this.buttonMyInterests.Text = "My Interests";
            this.buttonMyInterests.UseVisualStyleBackColor = false;
            this.buttonMyInterests.Click += new System.EventHandler(this.buttonMyInterests_Click);
            // 
            // buttonMessage
            // 
            this.buttonMessage.BackColor = System.Drawing.Color.Teal;
            this.buttonMessage.Location = new System.Drawing.Point(51, 358);
            this.buttonMessage.Name = "buttonMessage";
            this.buttonMessage.Size = new System.Drawing.Size(107, 43);
            this.buttonMessage.TabIndex = 18;
            this.buttonMessage.Text = "Message";
            this.buttonMessage.UseVisualStyleBackColor = false;
            this.buttonMessage.Click += new System.EventHandler(this.buttonMessage_Click);
            // 
            // buttonOpenChat
            // 
            this.buttonOpenChat.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.buttonOpenChat.Location = new System.Drawing.Point(46, 417);
            this.buttonOpenChat.Name = "buttonOpenChat";
            this.buttonOpenChat.Size = new System.Drawing.Size(112, 47);
            this.buttonOpenChat.TabIndex = 19;
            this.buttonOpenChat.Text = "Open Chat With";
            this.buttonOpenChat.UseVisualStyleBackColor = false;
            this.buttonOpenChat.Visible = false;
            this.buttonOpenChat.Click += new System.EventHandler(this.buttonOpenChat_Click);
            // 
            // DashboardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(26)))), ((int)(((byte)(32)))));
            this.ClientSize = new System.Drawing.Size(1343, 729);
            this.Controls.Add(this.buttonOpenChat);
            this.Controls.Add(this.buttonMessage);
            this.Controls.Add(this.buttonMyInterests);
            this.Controls.Add(this.buttonViewInterest);
            this.Controls.Add(this.buttonShowInterest);
            this.Controls.Add(this.buttonLearner);
            this.Controls.Add(this.buttonTutor);
            this.Controls.Add(this.buttonLogOut);
            this.Controls.Add(this.buttonEditAcc);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.buttonAllPosts);
            this.Controls.Add(this.buttonDeletePost);
            this.Controls.Add(this.buttonMyPost);
            this.Controls.Add(this.buttonDeleteAcc);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.textBoxSearch);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.buttonCreatePost);
            this.Controls.Add(this.buttonSearch);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DashboardForm";
            this.Text = "Student Dashboard Form";
            this.Load += new System.EventHandler(this.DashboardForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonSearch;
        private System.Windows.Forms.Button buttonCreatePost;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonEditAcc;
        private System.Windows.Forms.Button buttonDeleteAcc;
        private System.Windows.Forms.Button buttonMyPost;
        private System.Windows.Forms.Button buttonDeletePost;
        private System.Windows.Forms.Button buttonAllPosts;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonLogOut;
        private System.Windows.Forms.Button buttonTutor;
        private System.Windows.Forms.Button buttonLearner;
        private System.Windows.Forms.Button buttonShowInterest;
        private System.Windows.Forms.Button buttonViewInterest;
        private System.Windows.Forms.Button buttonMyInterests;
        private System.Windows.Forms.Button buttonMessage;
        private System.Windows.Forms.Button buttonOpenChat;
    }
}