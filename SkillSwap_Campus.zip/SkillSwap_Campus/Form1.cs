﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SkillSwap_Campus
{
    public partial class LoginForm : System.Windows.Forms.Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void buttonSignUp_Click(object sender, EventArgs e)
        {
            this.Hide();
            SignUpForm f2 = new SignUpForm();
            f2.Show();

        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            string studentId = textBoxID.Text;
            string password = textBoxPass.Text;
            for (int k = 0; k < studentId.Length; k++)
            {
                if (studentId[k] < '0' || studentId[k] > '9')
                {
                    MessageBox.Show("Student ID must be a valid number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            if (string.IsNullOrWhiteSpace(studentId) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter both Id and Password.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string connectionString = "data source=CATCHER\\SQLEXPRESS; database=PC; integrated security=SSPI";

            string query = "SELECT ISNULL(IsAdmin, 0) AS IsAdmin FROM students WHERE StudentId = @StudentId AND Password COLLATE SQL_Latin1_General_CP1_CS_AS = @Password";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@StudentId", studentId);
                    command.Parameters.AddWithValue("@Password", password);

                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            bool isAdmin = Convert.ToBoolean(reader["IsAdmin"]);
                            reader.Close();

                            MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Hide();

                            if (isAdmin)
                            {
                                AdminDashboardForm adminForm = new AdminDashboardForm(int.Parse(studentId));
                                adminForm.Show();
                            }
                            else
                            {
                                DashboardForm f3 = new DashboardForm(int.Parse(studentId));
                                f3.Show();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Invalid Id or Password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }
    }
}
