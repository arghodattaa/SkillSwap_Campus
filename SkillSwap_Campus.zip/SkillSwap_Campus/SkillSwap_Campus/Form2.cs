﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SkillSwap_Campus
{
    public partial class SignUpForm : Form
    {
        public SignUpForm()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void SignUpForm_Load(object sender, EventArgs e)
        {

        }

        private void buttonSignUp_Click(object sender, EventArgs e)
        {
            string connectionString = "data source=CATCHER\\SQLEXPRESS; database=PC; integrated security=SSPI";

            string name = textBoxName.Text.Trim();
            string studentId = textBoxID.Text.Trim();
            string email = textBoxEmail.Text.Trim();
            string phone = textBoxPhone.Text.Trim();
            string password = textBoxPass.Text.Trim();
            string dept = comboBoxDept.SelectedItem.ToString();
            string semester = comboBoxSem.SelectedItem.ToString();



            if (string.IsNullOrWhiteSpace(studentId) || string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(dept) || string.IsNullOrWhiteSpace(semester) ||
                 string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(phone) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("All fields must be filled out.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // if (!int.TryParse(age, out int parsedAge))
            // {
            //    MessageBox.Show("Age must be a valid number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //    return;
            // }

            //ID validation
            for ( int k = 0; k < studentId.Length; k++)
            {
                if (studentId[k] <'0' || studentId[k] > '9')
                {
                    MessageBox.Show("Student ID must be a valid number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }



            if (string.IsNullOrEmpty(email) ||
                !email.Contains("@") ||
                !email.EndsWith("@gmail.com", StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show("Email must be a valid Gmail address.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //gmail validation
            /*string tem = "gmail.com";
            int count = 0;
            for ( int k = email.Length-1, kk = tem.Length-1; kk>=0; kk--, k--)
            {
                if(email[k] == tem[kk])
                {
                    count++;
                }
            } 
            if( count != tem.Length)
            {
                MessageBox.Show("Email must be a valid Gmail address.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }*/

            //phone validation
            for (int k = 0; k < phone.Length; k++)
            {
                if (phone[k] < '0' || phone[k] > '9')
                {
                    MessageBox.Show("Number must be a valid number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            string checkQuery = "SELECT COUNT(1) FROM students WHERE StudentId = @StudentId";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                {
                    checkCommand.Parameters.AddWithValue("@StudentId", studentId);
                    int existingCount = (int)checkCommand.ExecuteScalar();

                    if (existingCount > 0)
                    {
                        MessageBox.Show("This Student ID is already registered. Please use a different ID.",
                                         "Duplicate Student ID", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }
            }

                string query = "INSERT INTO students (StudentId, StudentName, Dept, semester, Email, phone, Password) VALUES (@StudentId, @StudentName,@dept, @semester, @Email, @phone, @password)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@StudentId", studentId);
                    command.Parameters.AddWithValue("@StudentName", name);
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@phone", phone);
                    command.Parameters.AddWithValue("@password", password);
                    command.Parameters.AddWithValue("@dept", dept);
                    command.Parameters.AddWithValue("@semester", semester);
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Profile created successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                        LoginForm f1 = new LoginForm();
                        f1.Show();
                    }
                    else
                    {
                        MessageBox.Show("Failed to create the profile. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void comboBoxDept_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBoxName_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxSem_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Close();
            LoginForm LoginForm = new LoginForm();
            LoginForm.Show();
        }
    }
}
