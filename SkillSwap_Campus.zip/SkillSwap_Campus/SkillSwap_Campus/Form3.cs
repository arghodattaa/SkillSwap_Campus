﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SkillSwap_Campus
{
    public partial class DashboardForm : Form
    {
        string connectionString = "data source=CATCHER\\SQLEXPRESS; database=PC; integrated security=SSPI";
        public DashboardForm()
        {
            InitializeComponent();
        }

        int studentId;
        public DashboardForm(int i)
        {
            studentId = i;
            InitializeComponent();
            string query =  @"SELECT  p.Title,
                             p.StudentId,
                             c.CourseName,
                             p.Description,
                             p.Rate,
                             s.phone,
                             s.Email
                          FROM Posts AS p
                          INNER JOIN Students AS s
                          ON p.StudentId = s.StudentId
                          INNER JOIN Courses AS c
                          ON p.CourseId = c.CourseId";
            FillDataGridView(query);
        }

        private void FillDataGridView(string query)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    con.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);
                    dataGridView1.DataSource = dataTable;
                }
            }

        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            string searchValue = textBoxSearch.Text.Trim();

            if (string.IsNullOrWhiteSpace(searchValue))
            {
                MessageBox.Show("Please enter a search term.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query = @"SELECT  p.Title,
                             p.StudentId,
                             c.CourseName,
                             p.Description,
                             p.Rate
                          FROM Posts AS p
                          INNER JOIN Students AS s
                          ON p.StudentId = s.StudentId
                          INNER JOIN Courses AS c
                          ON p.CourseId = c.CourseId
                 WHERE CAST(p.StudentId AS VARCHAR(50)) LIKE @searchTerm
                 OR CAST(p.CourseId AS VARCHAR(50)) LIKE @searchTerm
                 OR CAST(c.CourseName AS VARCHAR(50)) LIKE @searchTerm";



            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@searchTerm", "%" + searchValue + "%");

                   
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);
                    dataGridView1.DataSource = dataTable;

                    if (dataTable.Rows.Count == 0)
                    {
                        MessageBox.Show("No matching rows found.", "Search Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void buttonCreatePost_Click(object sender, EventArgs e)
        {

            PostForm form2 = new PostForm(studentId);
            form2.Owner = this;
            form2.Show();
            this.Hide();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
         "Are you sure you want to exit the application?",
         "Confirm Exit",
         MessageBoxButtons.YesNo,
         MessageBoxIcon.Question
  );

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void buttonEditAcc_Click(object sender, EventArgs e)
        {
            this.Hide();
            EditAccForm f3 = new EditAccForm(studentId);
            f3.Show();
        }

        private void buttonDeleteAcc_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
            "Are you sure you want to delete this profile?",
            "Confirm Deletion",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning
);

            if (result == DialogResult.Yes)
            {
                string query = "DELETE FROM Students WHERE StudentId = @StudentId; " +
                               "DELETE FROM Posts WHERE StudentId = @StudentId";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@StudentId", studentId);

                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Profile deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            Close();
                        }
                        else
                        {
                            MessageBox.Show("No profile was found to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }
        private void FillDataGridView(string query, string studentId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@studentId", studentId);

                    SqlDataReader reader = command.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    dataGridView1.DataSource = dt;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sId = studentId.ToString();
            string query = @"SELECT p.PostId, p.Title, p.Description, p.CourseId, c.CourseName FROM Posts AS p INNER JOIN Courses AS c ON p.CourseId = c.CourseId INNER JOIN Students AS s ON p.StudentId = s.StudentId WHERE p.StudentId = @studentId ORDER BY p.PostId ";

           
                FillDataGridView(query, sId);
            }

        private void buttonAllPosts_Click(object sender, EventArgs e)
        {
            string query = @"SELECT  p.Title,
                             p.StudentId,
                             c.CourseName,
                             p.Description,
                             p.Rate,
                             s.phone,
                             s.Email
                          FROM Posts AS p
                          INNER JOIN Students AS s
                          ON p.StudentId = s.StudentId
                          INNER JOIN Courses AS c
                          ON p.CourseId = c.CourseId";
            FillDataGridView(query);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DeletePostForm df = new DeletePostForm();
            df.Show();
        }

        private void DashboardForm_Load(object sender, EventArgs e)
        {

        }

        private void buttonLogOut_Click(object sender, EventArgs e)
        {
            var confirm = MessageBox.Show(
                "Are you sure you want to logout?",
                "Confirm Logout",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirm == DialogResult.Yes)
            {

                LoginForm loginForm = new LoginForm();
                loginForm.Show();

                this.Close();
            }
        }

        private void buttonTutor_Click(object sender, EventArgs e)
        {
            string query = @"SELECT p.StudentId,
                     c.CourseName,
                     p.Description,
                     p.Rate,
                     s.phone,
                     s.Email
                  FROM Posts AS p
                  INNER JOIN Students AS s
                  ON p.StudentId = s.StudentId
                  INNER JOIN Courses AS c
                  ON p.CourseId = c.CourseId
                  WHERE p.Title = @title";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@title", "Want to Teach");

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);
                    dataGridView1.DataSource = dataTable;

                    if (dataTable.Rows.Count == 0)
                    {
                        MessageBox.Show("No Tutor's post was found.", "No Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void buttonLearner_Click(object sender, EventArgs e)
        {
            string query = @"SELECT p.StudentId,
                     c.CourseName,
                     p.Description,
                     p.Rate,
                     s.phone,
                     s.Email
                  FROM Posts AS p
                  INNER JOIN Students AS s
                  ON p.StudentId = s.StudentId
                  INNER JOIN Courses AS c
                  ON p.CourseId = c.CourseId
                  WHERE p.Title = @title";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@title", "Want to Learn");

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);
                    dataGridView1.DataSource = dataTable;

                    if (dataTable.Rows.Count == 0)
                    {
                        MessageBox.Show("No learner's post was found.", "No Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }
    }
    }
    

