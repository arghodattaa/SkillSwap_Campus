﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SkillSwap_Campus
{
    public partial class AdminDashboardForm : System.Windows.Forms.Form
    {
        string connectionString = "data source=CATCHER\\SQLEXPRESS; database=PC; integrated security=SSPI";
        int studentId;
        private const string TopAdminId = "1234";
        public AdminDashboardForm()
        {
            InitializeComponent();
            LoadCourses();
            LoadPosts();
        }

        public AdminDashboardForm(int studentId)
        {
            this.studentId = studentId;
            InitializeComponent();
            LoadCourses();
            LoadPosts();
            if (studentId.ToString() == TopAdminId)
            {
                LoadStudents();
            }
            else
            {
               tabControlAdmin.TabPages.Remove(tabPageManageAdmins);
            }
        }

        private void LoadCourses()
        {
            string query = "SELECT CourseId, CourseName FROM Courses ORDER BY CourseId";
            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridViewCourses.DataSource = dt;
            }
        }

        private void LoadStudents()
        {
            string query = "SELECT StudentId, StudentName, Email, IsAdmin FROM Students ORDER BY StudentId";
            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridViewStudents.DataSource = dt;
            }
        }

        private void AdminDashboardForm_Load(object sender, EventArgs e)
        {

        }

        private void buttonAddCourse_Click(object sender, EventArgs e)
        {
            string courseId = textBoxNewCourseId.Text.Trim();
            string courseName = textBoxNewCourseName.Text.Trim();

            if (string.IsNullOrWhiteSpace(courseId) || string.IsNullOrWhiteSpace(courseName))
            {
                MessageBox.Show("Please enter both a Course ID and Course Name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string checkQuery = "SELECT COUNT(1) FROM Courses WHERE CourseId = @CourseId";
                using (SqlCommand checkCmd = new SqlCommand(checkQuery, connection))
                {
                    checkCmd.Parameters.AddWithValue("@CourseId", courseId);
                    if ((int)checkCmd.ExecuteScalar() > 0)
                    {
                        MessageBox.Show("A course with this ID already exists.", "Duplicate Course", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }

                string insertQuery = "INSERT INTO Courses (CourseId, CourseName) VALUES (@CourseId, @CourseName)";
                using (SqlCommand insertCmd = new SqlCommand(insertQuery, connection))
                {
                    insertCmd.Parameters.AddWithValue("@CourseId", courseId);
                    insertCmd.Parameters.AddWithValue("@CourseName", courseName);
                    insertCmd.ExecuteNonQuery();
                }
            }

            textBoxNewCourseId.Clear();
            textBoxNewCourseName.Clear();
            MessageBox.Show("Course added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadCourses();
        }

        private void buttonDeleteCourse_Click(object sender, EventArgs e)
        {
            if (dataGridViewCourses.CurrentRow == null || dataGridViewCourses.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a course to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow row = dataGridViewCourses.SelectedRows[0];
            string courseId = row.Cells["CourseId"].Value.ToString();
            string courseName = row.Cells["CourseName"].Value.ToString();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string checkQuery = "SELECT COUNT(1) FROM Posts WHERE CourseId = @CourseId";
                using (SqlCommand checkCmd = new SqlCommand(checkQuery, connection))
                {
                    checkCmd.Parameters.AddWithValue("@CourseId", courseId);
                    int postCount = (int)checkCmd.ExecuteScalar();

                    if (postCount > 0)
                    {
                        MessageBox.Show($"Can't delete \"{courseName}\" — {postCount} post(s) still reference it. Delete those posts first.",
                            "Course In Use", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }

                DialogResult confirm = MessageBox.Show($"Delete course \"{courseName}\"?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirm != DialogResult.Yes) return;

                string deleteQuery = "DELETE FROM Courses WHERE CourseId = @CourseId";
                using (SqlCommand deleteCmd = new SqlCommand(deleteQuery, connection))
                {
                    deleteCmd.Parameters.AddWithValue("@CourseId", courseId);
                    deleteCmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Course deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadCourses();
        }

        private void LoadPosts()
        {
            string query = @"SELECT p.PostId, p.Title, s.StudentName, c.CourseName, p.Rate, p.Description
                          FROM Posts AS p
                          INNER JOIN Students AS s ON p.StudentId = s.StudentId
                          INNER JOIN Courses AS c ON p.CourseId = c.CourseId
                          ORDER BY p.PostId DESC";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridViewPosts.DataSource = dt;
            }
        }

        private void buttonDeletePost_Click(object sender, EventArgs e)
        {
            if (dataGridViewPosts.CurrentRow == null || dataGridViewPosts.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a post to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow row = dataGridViewPosts.SelectedRows[0];
            int postId = Convert.ToInt32(row.Cells["PostId"].Value);
            string title = row.Cells["Title"].Value.ToString();

            DialogResult confirm = MessageBox.Show(
                $"Delete this post (\"{title}\")? This will also remove any interests and chat messages tied to it.",
                "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (confirm != DialogResult.Yes) return;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();
                try
                {
                    string deleteMessagesQuery = @"DELETE FROM Messages 
                                                    WHERE InterestId IN (SELECT InterestId FROM Interests WHERE PostId = @PostId)";
                    using (SqlCommand cmd = new SqlCommand(deleteMessagesQuery, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("@PostId", postId);
                        cmd.ExecuteNonQuery();
                    }

                    string deleteInterestsQuery = "DELETE FROM Interests WHERE PostId = @PostId";
                    using (SqlCommand cmd = new SqlCommand(deleteInterestsQuery, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("@PostId", postId);
                        cmd.ExecuteNonQuery();
                    }

                    string deletePostQuery = "DELETE FROM Posts WHERE PostId = @PostId";
                    using (SqlCommand cmd = new SqlCommand(deletePostQuery, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("@PostId", postId);
                        cmd.ExecuteNonQuery();
                    }

                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    MessageBox.Show("Something went wrong while deleting this post.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            MessageBox.Show("Post deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadPosts();

        }

        private void buttonLogOut_Click(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
            this.Close();
        }

        private void buttonViewAsStudent_Click(object sender, EventArgs e)
        {
            DashboardForm studentView = new DashboardForm(studentId);
            studentView.Owner = this;
            studentView.Show();
            this.Hide();
        }

        private void textBoxNewCourseName_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonPromote_Click(object sender, EventArgs e)
        {
            if (studentId.ToString() != TopAdminId) return;

            if (dataGridViewStudents.CurrentRow == null || dataGridViewStudents.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a student to promote.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow row = dataGridViewStudents.SelectedRows[0];
            string targetId = row.Cells["StudentId"].Value.ToString();
            bool alreadyAdmin = Convert.ToBoolean(row.Cells["IsAdmin"].Value);

            if (alreadyAdmin)
            {
                MessageBox.Show("This student is already an admin.", "No Change Needed", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            DialogResult confirm = MessageBox.Show($"Promote Student ID {targetId} to admin?", "Confirm Promotion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm != DialogResult.Yes) return;

            string query = "UPDATE Students SET IsAdmin = 1 WHERE StudentId = @StudentId";
            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@StudentId", targetId);
                connection.Open();
                command.ExecuteNonQuery();
            }

            MessageBox.Show("Student promoted to admin.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadStudents();
        }

        private void buttonDemote_Click(object sender, EventArgs e)
        {
            if (studentId.ToString() != TopAdminId) return;

            if (dataGridViewStudents.CurrentRow == null || dataGridViewStudents.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an admin to demote.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow row = dataGridViewStudents.SelectedRows[0];
            string targetId = row.Cells["StudentId"].Value.ToString();
            bool isAdmin = Convert.ToBoolean(row.Cells["IsAdmin"].Value);

            if (targetId == TopAdminId)
            {
                MessageBox.Show("The top admin account can't be demoted.", "Not Allowed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!isAdmin)
            {
                MessageBox.Show("This student isn't an admin.", "No Change Needed", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DialogResult confirm = MessageBox.Show($"Demote Student ID {targetId} back to a regular student?", "Confirm Demotion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm != DialogResult.Yes) return;

            string query = "UPDATE Students SET IsAdmin = 0 WHERE StudentId = @StudentId";
            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@StudentId", targetId);
                connection.Open();
                command.ExecuteNonQuery();
            }

            MessageBox.Show("Admin demoted to student.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadStudents();
        }
    }
}
